import './App.css';
import BusinessInfo from './components/BusinessInfo';
import CustomPage from './components/Custom';
import QuickSetup from './components/QuickSetup';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

function App() {
  
  return (
     <Router>
      <Routes>
        <Route path="/" element={<QuickSetup />} />
        <Route path="/business" element={<BusinessInfo />} />
        <Route path="/custom" element={<CustomPage />} />
      </Routes>
    </Router>
  );
}



export default App;
